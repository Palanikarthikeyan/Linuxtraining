echo $1 $2 $3 $5
echo
echo $4 $2
echo
echo ${1} ${2} ${3}
echo 
echo $1 $2 $3 $4 $5 $6 $7 $8 $9
echo $1 $2 $3 $4 $5 $6 $7 $8 $9 $10 $11 $12 # $1->1st followed by0 
echo
echo ${10} ${11} ${12} ${13}
echo "Total no.of args:$#"
