echo "Enter a filename:" 
read fname
echo "About your input file:$fname details:-
-----------------------------------------------"
stat $fname
echo "----------------------------------------"
