
read -p "Enter a pattern:" key

grep $key /etc/passwd
if [ $? -ne 0 ]
then
	echo "Pattern is not matched"
fi
