fx(){
	port=5000
	echo "App port number:$port"
}
fx
echo
echo "From main script:$port"
