read -p "Enter your name:" name

if [ -z $name ];then
	echo "Sorry your input is empty"
else
	echo "Hello..$name"
fi
