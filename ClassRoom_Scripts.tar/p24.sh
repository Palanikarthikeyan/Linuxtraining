os=`uname`

if [ $os == "unix" ]
then
	echo "Matched-1"
elif [ $os == "aix" ]
then
	echo "Matched-2"
elif [ $os == "sunos" ]
then
	echo "Matched-3"
elif [ $os == "Linux" ]
then
	echo "Matched-4"
elif [ $os == "hpux" ]
then
	echo "Matched-5"
else
	echo "Not-Matched"
fi
