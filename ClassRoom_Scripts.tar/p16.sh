read -p "Enter a port number:" port

if [ $port -gt 500 ]
then
	echo "Valid port number"
else
	echo "Invalid range"
fi
