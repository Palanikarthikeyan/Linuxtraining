while :
do
echo "
1. unix
2. linux
3. aix
4. sunos
5. quit"
read -p "Enter your choice:" choice
	if [ $choice == 1 ]
	then
		var=unix
	elif [ $choice == 2 ]
	then	
		var=linux
	fi
	case $var in
	unix)  echo "Current process:-"
	       ps -f
	       ;;
	linux) echo "Kernel version `uname -r`" ;;
	aix) echo "mounted filesystem:-"
	     df -Th
	     ;;
	sunos) echo "Current loadbalance:-"
	       uptime
	       ;;
	quit) echo "Thank you!!!"
	      break
	      ;;
	*)  echo "Not matched"
	esac
done
