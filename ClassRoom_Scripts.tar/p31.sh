read -p "Enter a filename:" fname

if ! [ -f $fname ]
then
	echo "Sorry your input file is not a reg.file"
fi
read -p "Enter a pattern:" key
grep $key $fname
if [ $? -ne 0 ];then
	echo "Usage:Sorry pattern $key is not matched from $fname file"
fi	
