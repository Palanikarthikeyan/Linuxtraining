fsinfo()
{
	echo "Fstype:xfs"
	echo "Fmount:/"
	df -Th
}
