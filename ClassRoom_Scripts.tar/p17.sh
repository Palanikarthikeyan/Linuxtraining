
grep tcsh /etc/passwd

if [ $? -ne 0 ]
then
	echo "Pattern is not matched"
fi
