for var in date ls pwd uptime
do
	eval "$var"
done >r1.log
