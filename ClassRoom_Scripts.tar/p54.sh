
array=($@)

for var in ${array[@]}
do
	...
done
