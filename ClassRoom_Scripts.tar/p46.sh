pin=1234

c=0
while [ $c -lt 3 ]
do
	read -p "Enter a pin Number:" PIN
	c=`expr $c + 1`
	if [ $PIN -eq $pin ]
	then
		echo "Success pin is matched- at $c"
		break
	fi	
done
if [ $pin -ne $PIN ]
then
	echo "pin is blocked"
fi
