fperm="rwx"

read -p "Enter a filesystem type:" ftype
read -p "Enter a filesystem mount point:" fmount
read -p "Enter a filesystem  Size:" fsize

echo "
--------------------------------
File System Type:$ftype
--------------------------------
Mount point directory:$fmount
---------------------------------
FileSystem Size:$fsize
---------------------------------
Permission details:$fperm
----------------------------------"
