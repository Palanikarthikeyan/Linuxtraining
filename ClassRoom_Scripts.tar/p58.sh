echo "This is main script"

function display(){
	echo "Kernel: `uname -rs`"
	echo "Login shell:$SHELL"
	echo "Total no.of process:`ps -e|wc -l`"
	echo "Exit from $FUNCNAME block"
}
list(){
	echo "List of .log files:-"
	ls -l *.log
	echo "Exit from $FUNCNAME block"
}
display
sleep 2
#list 
echo "Exit from main script"
