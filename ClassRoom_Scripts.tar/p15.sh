read -p "Enter a partition name:" p1
read -p "Enter $p1 partition size:" s1

read -p "Enter a partition name:" p2
read -p "Enter $p2 partition size:" s2

total=`expr $s1 + $s2`
echo "
Partition name:$p1	Size:$s1 GB
Partition name:$p2	Size:$s2 GB
----------------------------------------
		Total   Size:$total GB
----------------------------------------"
