ftype="xfs"
fmount="/L1"
fsize="150GB"
fperm="rwx"

echo "
--------------------------------
File System Type:$ftype
--------------------------------
Mount point directory:$fmount
---------------------------------
FileSystem Size:$fsize
---------------------------------
Permission details:$fperm
----------------------------------"
