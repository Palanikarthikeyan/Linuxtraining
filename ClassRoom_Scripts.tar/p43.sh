select var in unix linux aix sunos quit
do
	case $var in
	unix)  echo "Current process:-"
	       ps -f
	       ;;
	linux) echo "Kernel version `uname -r`" ;;
	aix) echo "mounted filesystem:-"
	     df -Th
	     ;;
	sunos) echo "Current loadbalance:-"
	       uptime
	       ;;
	quit) echo "Thank you!!!"
	      break
	      ;;
	*)  echo "Not matched"
	esac
done
