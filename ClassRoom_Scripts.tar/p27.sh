
read -p "enter a filename file:" fname

if [ -e $fname ]
then
	if [ -f $fname ];then
		echo "File:$fname is a reg.file"
		ls -l $fname
	elif [ -d $fname ];then
		echo "File:$fname is a directory"
		ls -ld $fname
	else
		file $fname
	fi
else
	echo "Sorry file $fname is not exists"
fi
