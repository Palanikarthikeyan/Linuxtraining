read -p "Enter a modulename:" mvar
if [ $mvar == "bluetooth" -o $mvar == "nfs" -o $mvar == "ip_tables" ]
then
lsmod|grep "$mvar"
if [ $? -ne  0 ]
then
	echo "Usage:module $mvar is not loaded"
	if [ `whoami` == "root" ]
	then
		modprobe $mvar
	else
		echo "Sorry your not a root user"
		exit
	fi
else
	echo "module $mvar is already loaded"
	modinfo "$mvar"
		
fi
fi
