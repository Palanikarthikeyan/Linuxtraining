select os in linux unix winx sunos
do
	echo "Selected server name is:$os"
done
