fperm="rwx"

echo "Enter a filesystem type:"
read ftype
echo "Enter a filesystem mount point:"
read fmount
echo "Enter a filesystem  Size:"
read fsize
echo "
--------------------------------
File System Type:$ftype
--------------------------------
Mount point directory:$fmount
---------------------------------
FileSystem Size:$fsize
---------------------------------
Permission details:$fperm
----------------------------------"
