echo "working script file name:$0"
echo "Running script PID:$$"
