echo "List of log files $PWD"
for var in `ls *.log`
do
	echo "$var"
done
