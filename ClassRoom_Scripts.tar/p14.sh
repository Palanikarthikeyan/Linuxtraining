echo "BASH SHELL"
var=120
export var
sh -c "echo ==>$var"
sh -c "ps -f"
echo "->$var" # BASH SHELL

sh<<EOF
echo "====>$var<==="
echo "Current process:-"
ps -f
echo "____________________"
EOF
echo "Exit from BASH SHELL"
