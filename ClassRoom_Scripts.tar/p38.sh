i=10
while [ $i -lt 5 ] # 10<5  -False
do
	echo "while loop"
done

until [ $i -lt 5 ] # 10<5 - False - code block will execute
do
	echo "i value :$i"
	i=`expr $i - 1`
done
