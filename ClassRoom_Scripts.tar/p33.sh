echo "Display CPU Loadbalance - 5times"

i=0
while [ $i -lt 5 ]
do	
	uptime
	sleep 2
	i=`expr $i + 1`
done
