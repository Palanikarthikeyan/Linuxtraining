
for var in bash sh csh ksh tcsh zsh
do
	if [ $var == "csh" ]
	then
		continue
	else
		echo "$var"
	fi
done
