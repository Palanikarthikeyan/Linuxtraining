echo "This is sample shellscript"
echo "List of files:-"
#ls -l # command with args
sleep 3
echo "Current process:-"
echo "-------------------"
ps -f
sleep 2
echo "Login name:`whoami`" # command with command
echo # empty line
# df -Th
<<Abc
df -Th is a command - display mounted
filesystem details
-T option - filesystem type
-h option - human understanding view
Abc
# echo "ONE"
# echo "TWO"
# echo "THREE"
<<abc
ls
ps
whoami
abc
echo "End of the script"
