
if [ $# -ne 2 ]
then
	echo "Usage:Commandline argument allows any two directories"
	echo "$0 <dir1> <dir2>"
	exit
fi
if [ -d $1 -a -d $2 ]
then
	echo "Usage: Enter new directory"
	echo "$0 <dir1> <dir2>"
	exit
fi
mkdir $1 $2

if [ $? -ne 0 ]
then
	echo "Directory creation is failed"
fi

for var in `ls`
do
	if [ -d $var ];then
	  cp -r $var $1
	  if [ $? -ne 0 ];then
		echo "Directory copy is failed"
	  fi
       else
	  cp $var $2
	  if [ $? -ne 0 ];then
		echo "file copy operation is failed"
	  fi
      fi
done

tar -cf dir_backup.tar $1
tar -cf non_dir_backup.tar $2

