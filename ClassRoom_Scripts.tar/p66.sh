. /root/p64
echo "This is $0 script"
fsinfo
echo "Exit from script"
