read -p "Enter a shell name:" var

if [ $var == "bash" ]
then
	fname="bashrc"
elif [ $var == "ksh" ]
then
	fname="kshrc"
elif [ $var == "csh" ]
then
	fname="cshrc"
else
	var="/bin/nologin"
	fname="/etc/profile"
fi

echo -e "Shell name is:$var \t Profile filename:$fname"
