c=0
while [ $c -lt 5 ]
do
	read -p "Enter app name:" app
	if [ $app == "TestApp" ]
	then
		echo "Matched"
		break # exit from loop
	else
		echo "Try-again"
	fi
	c=`expr $c + 1`
done
echo "Exit from $0 file"
