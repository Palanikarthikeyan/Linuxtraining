
while :
do
	read -p "Enter app name:" app
	if [ $app == "TestApp" ]
	then
		echo "Matched"
		break # exit from loop
	else
		echo "Try-again"
	fi
done
echo "Exit from $0 file"
