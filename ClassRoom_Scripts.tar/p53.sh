cd $1 # from commandline
for var in `ls`
do
 echo $var
done
