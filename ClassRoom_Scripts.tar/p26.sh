read -p "Enter your os name:" os

case $os in
unix) echo "Matched-1" ;;
Linux|linux|LINUX) echo "Matched-2" ;;
*) echo "Not-matched"
esac

echo 
if [ $os == "unix" ]
then
	echo "Matched-1"
elif [ $os == "Linux" -o $os == "linux" -o $os == "LINUX" ]
then
	echo "Matched-2"
else
	echo "Not-matched"
fi
