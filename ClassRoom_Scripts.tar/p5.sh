os=`uname`
os_version=`uname -r`
DIR=`pwd`
count=`ps -e|wc -l` # to get total no.of process count
myname=`whoami`
myid=`id -u`

echo "My working kernel name is:$os
$os version is:$os_version
--------------------------------------
Working directory path:$DIR
---------------------------------------
Login name:$myname
Login id:$myid
---------------------------------------
Total no.of process count:$count
---------------------------------------"
