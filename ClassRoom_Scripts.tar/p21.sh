read -p "Enter a modulename:" mvar
if [ $mvar == "bluetooth" -o $mvar == "nfs" -o $mvar == "ip_tables" ]
then
lsmod|grep "$mvar"
if [ $? -ne 0 ]
then
	echo "Usage:module $var is not loaded"
	if [ `whoami` == "root" ]
	then
		modprobe $myvar
	else
		echo "Sorry your not a root user"
		exit
	fi
fi

