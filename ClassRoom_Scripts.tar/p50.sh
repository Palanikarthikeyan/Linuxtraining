if [ $# -ne 2 ]
then
	echo "Usage: commandline args allowd any two digits"
	echo "$0 <Number1> <Number2>"
	exit
fi
expr $1 + $2
