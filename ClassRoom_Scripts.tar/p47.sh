pin=1234

c=0
while [ $c -lt 3 ]
do
	read -p "Enter a pin Number:" PIN
	c=`expr $c + 1`
	if [ $PIN -eq $pin ]
	then
	  echo "Success pin is matched- at $c"
	  echo "SUCCESS pin is matched- count is:$c - At:`date`" >>pin.log
	  break
	else
	  echo "FAILED - user entry:$PIN At:`date`" >>pin.log
	fi	
done
if [ $pin -ne $PIN ]
then
	echo "pin is blocked"
fi
