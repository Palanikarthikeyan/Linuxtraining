echo "My working kernel name is:`uname`
`uname` version is:`uname -r`
--------------------------------------
Working directory path:`pwd`
---------------------------------------
Login name:`whoami`
Login id:`id -u`
---------------------------------------
Total no.of process count:`ps -e|wc -l`
---------------------------------------"
