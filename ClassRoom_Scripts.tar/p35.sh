i=0
while [ $i -lt 5 ]
do
	uptime >>Load_Balance.log 
	sleep 2
	ps    >>process.log
	sleep 1
	ping -c 3 google.com >>ping.log
	sleep 3
	i=`expr $i + 1`
done
