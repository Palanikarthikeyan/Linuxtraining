read -p "Enter a service name:" sname

systemctl is-active $sname

echo "About $sname service details:-

`systemctl status $sname`"

echo "-------------------------------------------------"
