echo "Working  directory path:$PWD"
echo
echo "working directory path:`pwd`"
