os=`uname`

case $os in
unix) echo "Matched-1" ;;
aix) echo "Matched-2" ;;
sunos) echo "Matched-3"
       ;;
Linux) echo "Matched-4"
	;;
hpux) echo "Matched-5"
	;;
*) echo "Not-Matched"
esac
