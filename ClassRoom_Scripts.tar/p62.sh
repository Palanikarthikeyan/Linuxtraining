
f1(){
	local v1=10
	v2=20
	v3=30
	return $v1
}
f1
echo "\$v1:$v1"
echo "\$v2:$v2  \$v3:$v3"
