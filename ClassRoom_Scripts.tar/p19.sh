if [ `whoami` == "root" ]  # if [ `id -u` -eq 0 ]  # if [ $UID -eq 0 ]
then
	echo "Admin tasks"
else
	echo "Sorry your not root user"
	exit # exit from script
fi

