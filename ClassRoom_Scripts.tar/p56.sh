while read var
do
	eval "$var"
done<cmd.txt >r1.log
