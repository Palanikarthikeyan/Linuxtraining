echo "Enter a n value:"
read n
echo "Enter a m value:"
read m
t=`expr $n + $m`
echo "Enter a x value:"
read x
r=`expr $x + $t`
s=`expr $r + 50`
echo "Enter a y value:"
read y
total=`expr $s + $y`
echo "total value:$total"
