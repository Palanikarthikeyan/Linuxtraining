frw(){
while read var
do
	eval "$var"
done<$1 >$2 # functioncall args value - formalparms
echo "Exit from $FUNCNAME block"
}

frw cmd.txt r2.log
sleep 3
frw $1 $2 # from command line arguments
