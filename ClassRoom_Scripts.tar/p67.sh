myport=5000
myapp=flask
version=4.23
author="Mr.ABC"

fdisplay(){
	uname -rs
	uptime
	whoami
	id -u
	echo "Today:`date +%D`"
}
