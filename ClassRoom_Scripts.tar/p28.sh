read -p "Enter a directory name:" dname
if [ -d $dname ];then
	echo "Directory:$dname is exists"
	echo "$dname details:-"
	ls -ld $dname
else
	mkdir $dname >>/var/log/test.log 2>&1
	if [ $? -eq 0 ];then
		echo "Directory $dname is created"
		ls -ld $dname	
	else
		echo "Sorry directory creation is failed"
		echo "Check your /var/log/test.log file"
	fi
fi
